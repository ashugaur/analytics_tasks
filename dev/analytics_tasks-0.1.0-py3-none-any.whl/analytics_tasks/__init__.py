"""Analytics Tasks - A collection of data analysis utilities."""

__version__ = "0.1.0"

# Import commonly used functions/classes for easy access
from .file_search.functions import *