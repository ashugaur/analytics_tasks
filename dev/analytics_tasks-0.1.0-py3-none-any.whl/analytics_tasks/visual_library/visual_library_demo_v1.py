## Dependencies
from pathlib import Path
from collections import defaultdict
import csv
import json


## create_site
def create_site(
    folder_to_scan,
    side_bar_width,
    page_color="#bb6e6e",
    toc_color="#007bff",
    toc_bg_color="rgba(255, 255, 255, 0.9)",
    modal_background_color = "rgba(212, 188, 150, 0.5)",
    image_extensions=[
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".bmp",
        ".svg",
        ".webp",
        ".jfif",
        ".xlsx",
        ".xlsm",
    ],
    exclude_folders=[],
    *,
    compact_site=None
):
    """
    Automatically generates an HTML gallery page by scanning a folder structure.
    Now with a fixed sidebar table of contents and CSV hover preview.

    Args:
        folder_to_scan (str): Path to the folder containing subfolders with images and related files
        page_color (str): Background color for the page (default: "#bb6e6e")
        toc_color (str): Color for the table of contents links (default: "#007bff")
        toc_bg_color (str): Background color for the TOC container (default: "rgba(255, 255, 255, 0.9)")
        output_file (str): Name of the output HTML file (default: "gallery.html")

    Returns:
        str: Path to the generated HTML file
    """

    if compact_site:
        compact_gallery_item_img_width = ''
        compact_image_container_height = 'height: 160px;'
    else:
        compact_gallery_item_img_width = 'width: 100%;'
        compact_image_container_height = ''

    # Define file type colors and priorities
    file_colors = {
        ".py": ("python", "#3776ab"),
        ".r": ("r", "#276dc3"),
        ".R": ("r", "#276dc3"),
        ".bas": ("basic", "#8b4513"),
        ".csv": ("csv", "#28a745"),
        ".xlsx": ("csv", "#15b63b"),
        ".xlsm": ("csv", "#11c93c"),
        ".jpg": ("jpg", "#dc3545"),
        ".jpeg": ("jpg", "#dc3545"),
        ".txt": ("txt", "#6c757d"),
        ".json": ("json", "#17a2b8"),
        ".xml": ("xml", "#fd7e14"),
        ".html": ("html", "#e83e8c"),
        ".js": ("js", "#ffc107"),
        ".css": ("css", "#20c997"),
    }

    def read_csv_preview(file_path, max_rows=5):
        """Read the first few rows of a CSV file for preview"""
        try:
            with open(file_path, 'r', encoding='utf-8', errors='ignore') as f:
                # Try to detect delimiter
                sample = f.read(1024)
                f.seek(0)
                
                sniffer = csv.Sniffer()
                delimiter = ','
                try:
                    delimiter = sniffer.sniff(sample).delimiter
                except Exception:
                    delimiter = ','
                
                reader = csv.reader(f, delimiter=delimiter)
                rows = []
                for i, row in enumerate(reader):
                    if i >= max_rows:
                        break
                    # Limit cell content length for display
                    row = [str(cell)[:50] + '...' if len(str(cell)) > 50 else str(cell) for cell in row]
                    rows.append(row)
                
                return rows
        except Exception as e:
            return [["Error reading file:", str(e)]]

    def scan_folder(folder_path):
        """Scan folder and organize files by base name"""
        folder_path = Path(folder_path)
        if not folder_path.exists():
            raise FileNotFoundError(f"Folder '{folder_path}' does not exist")

        gallery_data = {}
        csv_previews = {}  # Store CSV preview data

        # Scan each subfolder
        for subfolder in folder_path.iterdir():
            if not subfolder.is_dir() or subfolder.name in exclude_folders:
                continue

            subfolder_name = subfolder.name
            files_by_basename = defaultdict(list)

            # Group files by their base name (without extension)
            for file_path in subfolder.iterdir():
                if file_path.is_file():
                    basename = file_path.stem
                    extension = file_path.suffix.lower()
                    file_info = {
                        "name": file_path.name,
                        "extension": extension,
                        "path": str(file_path.relative_to(folder_path)).replace("\\", "/"),
                    }
                    
                    # Generate CSV preview if it's a CSV file
                    if extension == '.csv':
                        csv_data = read_csv_preview(file_path)
                        csv_previews[file_info["path"]] = csv_data
                    
                    files_by_basename[basename].append(file_info)

            # Process each group of files
            gallery_items = []
            for basename, files in files_by_basename.items():
                # Find the best image file
                image_file = None
                other_files = []

                for file_info in files:
                    if file_info["extension"] in image_extensions:
                        if image_file is None or image_extensions.index(
                            file_info["extension"]
                        ) < image_extensions.index(image_file["extension"]):
                            if image_file:
                                other_files.append(image_file)
                            image_file = file_info
                        else:
                            other_files.append(file_info)
                    else:
                        other_files.append(file_info)

                if image_file:
                    # Sort other files by extension for consistent display
                    other_files.sort(key=lambda x: x["extension"])

                    gallery_items.append(
                        {
                            "basename": basename,
                            "image": image_file,
                            "other_files": other_files,
                        }
                    )

            if gallery_items:
                # Sort items by basename for consistent ordering
                gallery_items.sort(key=lambda x: x["basename"])
                gallery_data[subfolder_name] = gallery_items

        return gallery_data, csv_previews

    def generate_html(gallery_data, csv_previews, page_color, toc_color, toc_bg_color, modal_background_color):
        """Generate HTML content with fixed sidebar TOC and CSV preview"""

        html_template = f"""<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visual library</title>
    <style>
        /* Global styles */
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}

        body {{
            font-family: Arial, sans-serif;
            background-color: {page_color};
            padding-left: 250px; /* Space for fixed sidebar */
            min-height: 100vh;
        }}

        /* Fixed Sidebar Table of Contents */
        .toc-sidebar {{
            position: fixed;
            top: 0;
            left: 0;
            width: {side_bar_width};
            height: 100vh;
            background-color: {toc_bg_color};
            padding: 15px 10px;
            box-shadow: 1px 0 4px rgba(0, 0, 0, 0.1);
            overflow-y: auto;
            z-index: 1000;
        }}

        .toc-title {{
            font-size: 14px;
            font-weight: bold;
            color: {toc_color};
            margin-bottom: 20px;
            text-align: center;
            border-bottom: 1px solid {toc_color};
            padding-bottom: 10px;
        }}

        .toc-links {{
            display: flex;
            flex-direction: column;
            gap: 8px;
        }}

        .toc-link {{
            color: {toc_color};
            text-decoration: none;
            # padding: 10px 15px;
            border-radius: 6px;
            # background-color: rgba({int(toc_color[1:3], 16)}, {int(toc_color[3:5], 16)}, {int(toc_color[5:7], 16)}, 0.1);
            # transition: all 0.1s ease;
            font-size: 14px;
            border-left: 3px solid transparent;
            display: block;
        }}

        .toc-link:hover {{
            background-color: {toc_color};
            color: {page_color};
            text-decoration: none;
            border-left-color: {toc_bg_color};
            transform: translateX(5px);
        }}

        # .toc-link.active {{
        #     background-color: {toc_color};
        #     color: {page_color};
        #     border-left-color: white;
        # }}

        /* Toggle button for mobile */
        # .toc-toggle {{
        #     display: none;
        #     position: fixed;
        #     top: 20px;
        #     left: 20px;
        #     z-index: 1001;
        #     background-color: {toc_color};
        #     color: {page_color};
        #     border: none;
        #     padding: 10px 15px;
        #     border-radius: 6px;
        #     cursor: pointer;
        #     font-size: 16px;
        # }}

        .toc-toggle:hover {{
            opacity: 0.4;
        }}

        /* Main content area */
        .main-content {{
            padding: 20px;
            min-height: 100vh;
        }}

        .gallery-container {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 10px;
            padding: 10px;
            max-width: 1200px;
            margin: 0 auto;
            background-color: {page_color};
        }}

        .gallery-item {{
            position: relative;
            border-radius: 8px;
            overflow: hidden;
            background-color: {page_color};
            box-shadow: 0 2px 8px rgba(0, 0, 0, 0.1);
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }}

        .gallery-item:hover {{
            transform: translateY(-1px);
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.2);
        }}

        .image-container {{
            position: relative;
            width: 100%;
            {compact_image_container_height}
            cursor: pointer;
        }}

        .gallery-item img {{
            {compact_gallery_item_img_width}
            height: 100%;
            object-fit: cover;
            display: block;
        }}

        .image-caption {{
            padding: 8px 10px;
            background-color: {page_color};
            # border-bottom: 1px solid {toc_color};
            font-size: 12px;
            color: {toc_color};
            text-align: center;
            font-weight: 500;
            word-break: break-word;
        }}

        .file-list {{
            padding: 5px;
            background-color: {page_color};
            border-top: 1px solid {page_color};
        }}

        .file-link {{
            display: inline-block;
            margin: 2px 5px 2px 0;
            padding: 4px 8px;
            color: white;
            text-decoration: none;
            border-radius: 4px;
            font-size: 12px;
            transition: background-color 0.3s ease;
            position: relative;
        }}

        .file-link:hover {{
            opacity: 0.9;
        }}

        /* CSV Preview Tooltip */
        .csv-preview {{
            display: none;
            position: absolute;
            bottom: 100%;
            left: 100%;
            transform: translateX(-35%);
            background-color: {page_color};
            border: 1px solid #ccc;
            border-radius: 6px;
            box-shadow: 0 4px 12px rgba(0, 0, 0, 0.3);
            z-index: 1500;
            max-width: 600px;
            max-height: 500px;
            overflow: auto;
            margin-bottom: 5px;
        }}

        .csv-preview table {{
            width: 100%;
            border-collapse: collapse;
            font-size: 11px;
            font-family: monospace;
        }}

        .csv-preview th,
        .csv-preview td {{
            border: 1px solid #ddd;
            padding: 4px 8px;
            text-align: left;
            max-width: 75px;
            overflow: hidden;
            text-overflow: ellipsis;
            white-space: nowrap;
            background-color: {page_color};
        }}

        .csv-preview th {{
            background-color: {page_color};
            font-weight: bold;
            position: sticky;
            top: 0;
            color: {toc_color}
        }}

        .csv-preview .preview-title {{
            padding: 8px;
            background-color: {page_color};
            border-bottom: 1px solid #ddd;
            font-weight: bold;
            font-size: 12px;
            color: {toc_color};
        }}

        /* Show CSV preview on hover */
        .file-link.csv:hover .csv-preview {{
            display: block;
        }}

        /* File type specific colors */"""

        # Add CSS for each file type
        for ext, (class_name, color) in file_colors.items():
            html_template += f"""
        .file-link.{class_name} {{
            background-color: {color};
        }}"""

        html_template += f"""
        /* Modal styles */
        .modal {{
            display: none;
            position: fixed;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            background-color: rgba(0, 0, 0, 0.3);
            z-index: 2000;
        }}

        .modal-content {{
            position: relative;
            max-width: 90vw;
            max-height: 90vh;
            margin: 5% auto;
            padding: 10px;
            background-color: {modal_background_color};
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.5);
        }}

        .modal img {{
            max-width: 100%;
            max-height: 70vh;
            display: block;
            margin: 0 auto;
        }}

        .close-btn {{
            position: absolute;
            top: 10px;
            right: 15px;
            cursor: pointer;
            font-size: 24px;
            color: #666;
            transition: opacity 0.3s ease;
        }}

        .close-btn:hover {{
            opacity: 0.8;
        }}

        h2 {{
            color: {toc_color};
            margin: 30px auto 10px auto;
            max-width: 1200px;
            font-size: 20px;
            text-transform: capitalize;
            scroll-margin-top: 20px;
        }}

        /* Responsive design */
        @media (max-width: 768px) {{
            body {{
                padding-left: 0;
            }}

            .toc-sidebar {{
                transform: translateX(-100%);
                transition: transform 0.3s ease;
            }}

            .toc-sidebar.open {{
                transform: translateX(0);
            }}

            .toc-toggle {{
                display: block;
            }}

            .main-content {{
                padding: 60px 20px 20px 20px;
            }}

            .gallery-container {{
                grid-template-columns: 1fr;
            }}

            .gallery-item {{
                margin-bottom: 20px;
            }}

            .csv-preview {{
                max-width: 300px;
                left: 0;
                transform: none;
            }}
        }}

        /* Scrollbar styling for webkit browsers */
        .toc-sidebar::-webkit-scrollbar {{
            width: 3px;
        }}

        .toc-sidebar::-webkit-scrollbar-track {{
            background: #f1f1f1;
            border-radius: 3px;
        }}

        .toc-sidebar::-webkit-scrollbar-thumb {{
            background: #c1c1c1;
            border-radius: 3px;
        }}

        .toc-sidebar::-webkit-scrollbar-thumb:hover {{
            background: #a8a8a8;
        }}

        .csv-preview::-webkit-scrollbar {{
            width: 6px;
            height: 6px;
        }}

        .csv-preview::-webkit-scrollbar-track {{
            background: #f1f1f1;
        }}

        .csv-preview::-webkit-scrollbar-thumb {{
            background: #c1c1c1;
            border-radius: 3px;
        }}
    </style>
</head>
<body>"""

        # Embed CSV data as JavaScript
        html_template += f"""
    <script>
        const csvData = {json.dumps(csv_previews)};
    </script>"""

        # Generate Mobile Toggle Button
        html_template += """
    <button class="toc-toggle" onclick="toggleSidebar()">☰ Sections</button>"""

        # Generate Fixed Sidebar Table of Contents
        section_names = sorted(gallery_data.keys())
        if section_names:
            html_template += """
    <div class="toc-sidebar" id="tocSidebar">
        <div class="toc-title">Visual Library</div>
        <div class="toc-links">"""

            for section_name in section_names:
                # Create anchor-friendly ID
                section_id = section_name.lower().replace(" ", "-").replace("_", "-")

                html_template += f"""
            <a href="#{section_id}" class="toc-link" onclick="closeSidebarOnMobile()">{section_name}</a>"""

            html_template += """
        </div>
    </div>"""

        # Main content area
        html_template += """
    <div class="main-content">"""

        # Generate gallery sections
        for section_name, items in sorted(gallery_data.items()):
            # Create anchor-friendly ID
            section_id = section_name.lower().replace(" ", "-").replace("_", "-")

            html_template += f'''
        <h2 id="{section_id}">{section_name}</h2>
        <div class="gallery-container">'''

            for item in items:
                image_info = item["image"]
                alt_text = item["basename"].replace("_", " ").title()

                html_template += f'''
            <div class="gallery-item">
                <div class="image-container">
                    <img src="{image_info["path"]}" alt="{alt_text}">
                </div>
                <div class="image-caption">
                    {image_info["name"]}
                </div>'''

                if item["other_files"]:
                    html_template += """
                <div class="file-list">"""

                    for file_info in item["other_files"]:
                        ext = file_info["extension"]
                        class_name = file_colors.get(ext, ("file", "#6c757d"))[0]

                        # Create display name for file link
                        if file_info["name"].startswith(item["basename"]):
                            display_name = ext
                        else:
                            display_name = file_info["name"]

                        html_template += f'''
                    <a href="{file_info["path"]}" class="file-link {class_name}" target="_blank" data-file-path="{file_info["path"]}">{display_name}'''
                        
                        # Add CSV preview div if it's a CSV file
                        if ext == '.csv' and file_info["path"] in csv_previews:
                            html_template += '''
                        <div class="csv-preview">
                            <div class="csv-table-container"></div>
                        </div>'''
                        
                        html_template += '</a>'

                    html_template += """
                </div>"""

                html_template += """
            </div>"""

            html_template += """
        </div>"""

        # Close main content div
        html_template += """
    </div>"""

        # Add modal and JavaScript
        html_template += """

    <!-- Modal Container -->
    <div class="modal">
        <div class="modal-content">
            <span class="close-btn">×</span>
            <img id="modal-image" src="" alt="Modal Image">
        </div>
    </div>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const imageContainers = document.querySelectorAll('.image-container');
            const modalImage = document.getElementById('modal-image');
            const tocLinks = document.querySelectorAll('.toc-link');

            // Initialize CSV previews
            initializeCsvPreviews();

            // Open modal on image click
            imageContainers.forEach(container => {
                container.addEventListener('click', () => {
                    const img = container.querySelector('img');
                    const modal = document.querySelector('.modal');
                    modalImage.src = img.src;
                    modalImage.alt = img.alt;
                    modal.style.display = 'block';
                });
            });

            // Close modal when clicking close button
            document.querySelector('.close-btn').addEventListener('click', () => {
                document.querySelector('.modal').style.display = 'none';
            });

            // Close modal when clicking outside the modal content
            window.onclick = function(event) {
                const modal = document.querySelector('.modal');
                if (event.target == modal) {
                    modal.style.display = 'none';
                }
            };

            // Smooth scrolling for TOC links
            tocLinks.forEach(link => {
                link.addEventListener('click', function(e) {
                    e.preventDefault();
                    const targetId = this.getAttribute('href');
                    const targetElement = document.querySelector(targetId);
                    if (targetElement) {
                        targetElement.scrollIntoView({
                            behavior: 'smooth',
                            block: 'start'
                        });
                    }
                });
            });

            // Highlight active section in TOC
            function updateActiveSection() {
                const sections = document.querySelectorAll('h2[id]');
                const scrollPos = window.scrollY + 100;

                sections.forEach(section => {
                    const sectionTop = section.offsetTop;
                    const sectionBottom = sectionTop + section.offsetHeight;
                    const sectionId = section.getAttribute('id');
                    const tocLink = document.querySelector(`a[href="#${sectionId}"]`);

                    if (scrollPos >= sectionTop && scrollPos < sectionBottom) {
                        tocLinks.forEach(link => link.classList.remove('active'));
                        if (tocLink) tocLink.classList.add('active');
                    }
                });
            }

            // Update active section on scroll
            window.addEventListener('scroll', updateActiveSection);
            updateActiveSection(); // Initial call
        });

        // Initialize CSV preview functionality
        function initializeCsvPreviews() {
            const csvLinks = document.querySelectorAll('.file-link.csv[data-file-path]');
            
            csvLinks.forEach(link => {
                const filePath = link.getAttribute('data-file-path');
                const previewDiv = link.querySelector('.csv-preview .csv-table-container');
                
                if (previewDiv && csvData[filePath]) {
                    const csvRows = csvData[filePath];
                    
                    // Create table
                    const table = document.createElement('table');
                    
                    // Add rows
                    csvRows.forEach((row, index) => {
                        const tr = document.createElement('tr');
                        
                        row.forEach(cell => {
                            const td = document.createElement(index === 0 ? 'th' : 'td');
                            td.textContent = cell;
                            td.title = cell; // Show full content on hover
                            tr.appendChild(td);
                        });
                        
                        table.appendChild(tr);
                    });
                    
                    previewDiv.appendChild(table);
                }
            });
        }

        // Mobile sidebar toggle functions
        function toggleSidebar() {
            const sidebar = document.getElementById('tocSidebar');
            sidebar.classList.toggle('open');
        }

        function closeSidebarOnMobile() {
            if (window.innerWidth <= 768) {
                const sidebar = document.getElementById('tocSidebar');
                sidebar.classList.remove('open');
            }
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            if (window.innerWidth <= 768) {
                const sidebar = document.getElementById('tocSidebar');
                const toggle = document.querySelector('.toc-toggle');
                
                if (!sidebar.contains(event.target) && !toggle.contains(event.target)) {
                    sidebar.classList.remove('open');
                }
            }
        });
    </script>
</body>
</html>"""

        return html_template

    try:
        # Scan the folder
        print(f"Scanning folder: {folder_to_scan}")
        gallery_data, csv_previews = scan_folder(folder_to_scan)

        if not gallery_data:
            print("No image files found in subfolders!")
            return None

        # Generate HTML
        print("Generating HTML...")
        html_content = generate_html(gallery_data, csv_previews, page_color, toc_color, toc_bg_color, modal_background_color)

        # Write to file
        output_path = Path(folder_to_scan) / "visual_library.html"
        with open(output_path, "w", encoding="utf-8") as f:
            f.write(html_content)

        # Print summary
        total_items = sum(len(items) for items in gallery_data.values())
        csv_count = len(csv_previews)
        print("Gallery created successfully!")
        print(f"- {len(gallery_data)} categories")
        print(f"- {total_items} image sets")
        print(f"- {csv_count} CSV files with preview")
        print(f"- Output: {output_path}")

        return str(output_path)

    except Exception as e:
        print(f"Error creating gallery: {e}")
        return None